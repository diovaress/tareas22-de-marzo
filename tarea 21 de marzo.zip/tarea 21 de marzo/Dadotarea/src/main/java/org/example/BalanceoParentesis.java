package org.example;

import java.util.Stack;

public class BalanceoParentesis {

    public static boolean estaBalanceado(String secuencia) {
        Stack<Character> pila = new Stack<>();

        for (char c : secuencia.toCharArray()) {
            if (esApertura(c)) {
                pila.push(c);
            } else if (esCierre(c)) {
                if (pila.isEmpty() || !coinciden(pila.pop(), c)) {
                    return false;
                }
            }
        }
        return pila.isEmpty();
    }

    private static boolean esApertura(char c) {
        return c == '(' || c == '{' || c == '[';
    }

    private static boolean esCierre(char c) {
        return c == ')' || c == '}' || c == ']';
    }

    private static boolean coinciden(char apertura, char cierre) {
        return (apertura == '(' && cierre == ')') ||
                (apertura == '{' && cierre == '}') ||
                (apertura == '[' && cierre == ']');
    }

    public static void main(String[] args) {
        String[] pruebas = {"{[()]}", "{[(])}", "()", "{}[]", "(]", ""};

        for (String prueba : pruebas) {
            System.out.println(prueba + " -> " + estaBalanceado(prueba));
        }
    }
}
