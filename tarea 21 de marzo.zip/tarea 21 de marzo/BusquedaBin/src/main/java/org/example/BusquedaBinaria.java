public class BusquedaBinaria {

    public static int buscarNumero(int[] lista, int objetivo) {
        int izquierda = 0;
        int derecha = lista.length - 1;

        while (izquierda <= derecha) {
            int medio = (izquierda + derecha) / 2;

            if (lista[medio] == objetivo) {
                return medio;
            }

            if (lista[medio] < objetivo) {
                izquierda = medio + 1;
            } else {
                derecha = medio - 1;
            }
        }

        return -1;
    }

    public static void main(String[] args) {
        int[] lista = {1, 3, 5, 7, 9, 11, 15};
        int[] objetivos = {7, 4, 1, 15, 10};

        for (int objetivo : objetivos) {
            int resultado = buscarNumero(lista, objetivo);
            if (resultado != -1) {
                System.out.println("Buscar: " + objetivo + " -> Encontrado en el índice # " + resultado);
            } else {
                System.out.println("Buscar: " + objetivo + " -> No fue encontrado (-1)");
            }
        }
    }
}
