import java.util.Random;

public class BusquedaBinaria {

    public static int buscarNumero(int[] lista, int objetivo) {
        int izquierda = 0;
        int derecha = lista.length - 1;

        while (izquierda <= derecha) {
            int medio = izquierda + (derecha - izquierda) / 2;

            if (lista[medio] == objetivo) {
                return medio;
            }

            if (lista[medio] < objetivo) {
                izquierda = medio + 1;
            } else {
                derecha = medio - 1;
            }
        }
        return -1;
    }

    public static void main(String[] args) {
        // Lista de números ordenados (para realizar la búsqueda binaria)
        int[] lista = new int[]{1, 3, 5, 7, 9, 11, 15};

        // Simulamos la búsqueda de 5 números aleatorios entre 1 y 20
        Random rand = new Random();
        for (int i = 0; i < 5; i++) {
            int objetivo = rand.nextInt(20) + 1;  // Números aleatorios entre 1 y 20
            int resultado = buscarNumero(lista, objetivo);
            String mensaje = (resultado != -1)
                    ? "Buscar: " + objetivo + " -> Encontrado en el índice # " + resultado
                    : "Buscar: " + objetivo + " -> No fue encontrado (-1)";

            System.out.println(mensaje);
        }

        // Llamamos al siguiente fragmento del código para automatizar la cola de turnos
        ColaTurnos colaTurnos = new ColaTurnos();
        for (int i = 1; i <= 5; i++) {
            colaTurnos.agregarTurno(i);  // Agregar turnos automáticamente
        }

        colaTurnos.mostrarTurnos();  // Muestra los turnos en espera

        // Atendemos 3 turnos de manera automática
        for (int i = 0; i < 3; i++) {
            colaTurnos.atenderTurno();
        }
    }
}
